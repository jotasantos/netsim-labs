import os

release = "4.0.0-0478a014"
json = "4.0.0"
text = "4.0.0"
version = os.environ.get('EXABGP_VERSION',release)

# Do not change the first line as it is parsed by scripts

if __name__ == '__main__':
	import sys
	sys.stdout.write(version)
