class Command (object):
	from exabgp.reactor.api.command.text import Text
